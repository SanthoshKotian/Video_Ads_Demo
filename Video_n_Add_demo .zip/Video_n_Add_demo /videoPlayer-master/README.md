# videoPlayer
A pure javascript video player
