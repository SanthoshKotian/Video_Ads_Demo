
document.addEventListener("DOMContentLoaded", function() { startplayer(); }, false);

function startplayer(){
 
    
    /*
var videodiv= document.getElementById('buttonPanel');
   
   var videoscript = document.createElement("VIDEO");
   videoscript.setAttribute("class", "image");
   videoscript.setAttribute("id", "videoid");
   videoscript.setAttribute("width", "100%");

  if (videoscript.canPlayType("video/mp4")) {
    videoscript.setAttribute("src","http://techslides.com/demos/sample-videos/small.mp4");
  } else {
    videoscript.setAttribute("src","http://techslides.com/demos/sample-videos/small.ogg");
  }

  videoscript.setAttribute("controls", "controls");
  videodiv.appendChild(videoscript);

  document.getElementById("videoid").addEventListener("mouseover", mouseOver);
document.getElementById("videoid").addEventListener("mouseout", mouseOut);

function mouseOver() {
  document.getElementById("videoid").play();
}

function mouseOut() {
  document.getElementById("videoid").pause();
}

*/
  var div = document.getElementById('overbtn');
  
  var button_one = document.createElement("BUTTON");
  button_one.innerHTML = "WEBSITE";
  button_one.setAttribute("class", "website");
  var anchor = document.createElement("A");
  /*var Atext = document.createTextNode("Learn more");*/
  anchor.setAttribute("href", "https://www.amazon.com");
  anchor.setAttribute("id", "ach1");
  anchor.setAttribute("class", "achName1");
  anchor.setAttribute("target", "_blank");
  anchor.appendChild(button_one);
       div.appendChild(anchor);
       
       
  var button_two = document.createElement("BUTTON");
  button_two.innerHTML = "CALL";
  button_two.setAttribute("class", "Call");
  var callachor = document.createElement("A");
  
  callachor.setAttribute("href", "tel:+660123456789");
  callachor.setAttribute("id", "ach2");
  callachor.setAttribute("class", "achName2");
  callachor.setAttribute("target", "_blank");
  callachor.appendChild(button_two);
       div.appendChild(callachor);
       
       
  var button_three = document.createElement("BUTTON");
  button_three.innerHTML = "EMAIL";
  button_three.setAttribute("class", "Email");
  var emailanchor = document.createElement("A");
  
  emailanchor.setAttribute("href", "mailto:santhosh@mnshettytech.com");
  emailanchor.setAttribute("id", "ach3");
  emailanchor.setAttribute("class", "achName3");
  emailanchor.setAttribute("target", "_top");
  emailanchor.appendChild(button_three);
       div.appendChild(emailanchor);
       
  
   var button_four = document.createElement("BUTTON");
   button_four.innerHTML = "SMS";
   button_four.setAttribute("class", "Sms");
   var smsanchor = document.createElement("A");
  
  smsanchor.setAttribute("href", "sms:+91 9480961591?body=this is the text message to send");
  smsanchor.setAttribute("id", "ach3");
  smsanchor.setAttribute("class", "achName4");
  smsanchor.setAttribute("target", "_blank");
  smsanchor.appendChild(button_four);
       div.appendChild(smsanchor);
       
}
 
