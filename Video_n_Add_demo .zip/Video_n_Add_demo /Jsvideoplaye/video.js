
document.addEventListener("DOMContentLoaded", function() { startplayer(); }, false);





function startplayer() 
{

   
    
 player = document.getElementById('myVideo');
 player.controls = false;
}

function play_vid()
{
 player.play();
 var div = document.getElementById('ach1').remove();
}

function pause_vid()
{
 player.pause();
 
   var div = document.getElementById('myDiv');
   
   var btn = document.createElement("BUTTON");
  btn.innerHTML = "Learn more";
  btn.setAttribute("id", "button1");
 
     
  var x = document.createElement("A");
  var t = document.createTextNode("Learn more");

  x.setAttribute("href", "https://www.amazon.com");
  x.setAttribute("id", "ach1");
  x.setAttribute("class", "achName");
  x.setAttribute("target", "_blank");
 
  if(!document.getElementById('ach1')){
      
       x.appendChild(btn);
       div.appendChild(x);
      
   }else{
      
   var div = document.getElementById('ach1').remove();
       
  }
 
  
}

function stop_vid() 
{
 player.pause();
 player.currentTime = 0;
 var div = document.getElementById('ach1').remove();
}
function change_vol()
{
 player.volume=document.getElementById("change_vol").value;
}

 
