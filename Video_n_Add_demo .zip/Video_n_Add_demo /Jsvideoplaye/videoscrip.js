document.addEventListener("DOMContentLoaded", function() { loadplayer(); }, false);



function loadplayer(){
var videodiv= document.getElementById('buttonPanel');

 var videoscript = document.createElement("VIDEO");
   videoscript.setAttribute("class", "image");
   videoscript.setAttribute("id", "videoid");
   videoscript.setAttribute("width", "100%");

  if (videoscript.canPlayType("video/mp4")) {
    videoscript.setAttribute("src","http://techslides.com/demos/sample-videos/small.mp4");
  } else {
    videoscript.setAttribute("src","http://techslides.com/demos/sample-videos/small.ogg");
  }

  videoscript.setAttribute("controls", "controls");
  videodiv.appendChild(videoscript);
       

 document.getElementById("videoid").addEventListener("mouseover", mouseOver);
document.getElementById("videoid").addEventListener("mouseout", mouseOut);

function mouseOver() {
  document.getElementById("videoid").play();
}

function mouseOut() {
  document.getElementById("videoid").pause();
  
}
 
}
