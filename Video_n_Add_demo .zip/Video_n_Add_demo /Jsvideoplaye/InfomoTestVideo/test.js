 
document.addEventListener("DOMContentLoaded", function() { startplayer(); }, false);

function startplayer(){



  var div = document.getElementById('row');
  
  var button_one = document.createElement("BUTTON");
  button_one.innerHTML = "WEBSITE";
  button_one.setAttribute("class", "website");
  var anchor = document.createElement("A");
  /*var Atext = document.createTextNode("Learn more");*/
  anchor.setAttribute("href", "https://www.amazon.com");
  anchor.setAttribute("id", "ach1");
  anchor.setAttribute("class", "button");
  anchor.setAttribute("target", "_blank");
 // anchor.appendChild(button_one);
       div.appendChild(anchor);
       
       
  var button_two = document.createElement("BUTTON");
  button_two.innerHTML = "CALL";
  button_two.setAttribute("class", "Call");
  var callachor = document.createElement("A");
  
  callachor.setAttribute("href", "https://www.amazon.com");
  callachor.setAttribute("id", "ach2");
  callachor.setAttribute("class", "button");
  callachor.setAttribute("target", "_blank");
 // callachor.appendChild(button_two);
       div.appendChild(callachor);
       
       
  var button_three = document.createElement("BUTTON");
  button_three.innerHTML = "EMAIL";
  button_three.setAttribute("class", "Email");
  var emailanchor = document.createElement("A");
  
  emailanchor.setAttribute("href", "https://www.amazon.com");
  emailanchor.setAttribute("id", "ach3");
  emailanchor.setAttribute("class", "button");
  emailanchor.setAttribute("target", "_blank");
 // emailanchor.appendChild(button_three);
       div.appendChild(emailanchor);
       
  
   var button_four = document.createElement("BUTTON");
   button_four.innerHTML = "SMS";
   button_four.setAttribute("class", "Sms");
   var smsanchor = document.createElement("A");
  
  smsanchor.setAttribute("href", "https://www.amazon.com");
  smsanchor.setAttribute("id", "ach4");
  smsanchor.setAttribute("class", "button");
  smsanchor.setAttribute("target", "_blank");
 // smsanchor.appendChild(button_four);
       div.appendChild(smsanchor);
       
}
